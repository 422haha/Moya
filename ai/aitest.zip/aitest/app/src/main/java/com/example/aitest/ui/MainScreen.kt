package com.example.aitest.ui

import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.aitest.DataProcess
import com.example.aitest.Result

@Composable
fun MainScreen(
    dataProcess: DataProcess,
    ortEnvironment: OrtEnvironment,
    session: OrtSession
) {
    var detectionResults by remember { mutableStateOf<List<Result>>(emptyList()) }
    var hasCameraPermission by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // 권한을 요청하고 결과를 처리
    RequestCameraPermission { isGranted ->
        hasCameraPermission = isGranted
    }

    Scaffold { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // 권한이 허용되었을 때만 카메라 프리뷰를 표시
            if (hasCameraPermission) {
                CameraPreview(
                    dataProcess = dataProcess,
                    ortEnvironment = ortEnvironment,
                    session = session,
                    onResultsAvailable = { results ->
                        detectionResults = results
                    }
                )

                Column(modifier = Modifier.padding(16.dp)) {
                    if (detectionResults.isNotEmpty()) {
                        Text("Detected Objects:", color = Color.Black)
                        detectionResults.forEach { result ->
                            Text(
                                text = "Class: ${dataProcess.classes[result.classIndex]}, Score: ${result.score}",
                                color = Color.Black
                            )
                        }
                    }
                }
            } else {
                // 권한이 없을 때 사용자에게 알림을 표시할 수 있습니다.
                Toast.makeText(LocalContext.current, "카메라 권한이 필요합니다.", Toast.LENGTH_SHORT).show()
            }
        }
    }
    DrawBox(detectionResults = detectionResults)
}

@Composable
fun RequestCameraPermission(
    onPermissionResult: (Boolean) -> Unit
) {
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        onPermissionResult(isGranted)
    }

    LaunchedEffect(Unit) {
        permissionLauncher.launch(android.Manifest.permission.CAMERA)
    }
}
