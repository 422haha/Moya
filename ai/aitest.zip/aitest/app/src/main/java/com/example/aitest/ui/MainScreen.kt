package com.example.aitest.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.example.aitest.DataProcess
import com.example.aitest.Result

@Composable
fun MainScreen(dataProcess: DataProcess) {
    var selectedScreen by remember {
        mutableStateOf("camera")
    }

    var detectionResults by remember { mutableStateOf(emptyList<Result>()) }

    Scaffold { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Row {
                Button(onClick = { selectedScreen = "camera" }) {
                    Text(text = "camera")
                }
                Button(onClick = { selectedScreen = "gallery" }) {
                    Text(text = "gallery")
                }
            }
            when (selectedScreen) {
                "camera" -> CameraPreview(
                    dataProcess = dataProcess,
                    onResultsAvailable = { results ->
                        detectionResults = results
                    }
                )

                "gallery" -> GalleryScreen(
                    dataProcess = dataProcess,
                    onResultsAvailable = { results ->
                        detectionResults = results
                    }
                )
            }
        }

        DrawBox(detectionResults = detectionResults)
    }
}