package com.example.aitest.ui

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.aitest.DataProcess
import com.example.aitest.DataProcess.Companion.INPUT_SIZE
import com.example.aitest.Result
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Collections
import java.util.concurrent.Executors

@Composable
fun CameraPreview(
    dataProcess: DataProcess,
    ortEnvironment: OrtEnvironment,
    session: OrtSession,
    onResultsAvailable: (List<Result>) -> Unit
) {
    val context = LocalContext.current
    val previewView = remember { PreviewView(context) }
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    AndroidView(
        factory = { previewView },
        modifier = Modifier.fillMaxSize()
    ) {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()
            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            val preview = Preview.Builder()
                .build()

            preview.setSurfaceProvider(previewView.surfaceProvider)

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()

            analysis.setAnalyzer(Executors.newSingleThreadExecutor()) { imageProxy ->
                scope.launch(Dispatchers.Default) {
                    val bitmap = dataProcess.imageToBitmap(imageProxy)
                    val floatBuilder = dataProcess.bitmapToFloatBuffer(bitmap)
                    val inputName = session.inputNames.iterator().next()
                    val shape = longArrayOf(
                        DataProcess.BATCH_SIZE.toLong(),
                        DataProcess.PIXEL_SIZE.toLong(),
                        INPUT_SIZE.toLong(),
                        INPUT_SIZE.toLong()
                    )
                    val inputTensor = OnnxTensor.createTensor(ortEnvironment, floatBuilder, shape)
                    val resultTensor = session.run(Collections.singletonMap(inputName, inputTensor))
                    val outputs = resultTensor[0].value as Array<*>
                    val results =
                        dataProcess.outputsToNPMSPredictions(outputs)
                    onResultsAvailable(results)

                    imageProxy.close()
                }
            }

            try {
                cameraProvider.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    analysis
                )
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }, ContextCompat.getMainExecutor(context))
    }
}