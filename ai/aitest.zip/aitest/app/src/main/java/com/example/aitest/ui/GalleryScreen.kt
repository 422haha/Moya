package com.example.aitest.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.aitest.DataProcess
import com.example.aitest.Result

@Composable
fun GalleryScreen(
    dataProcess: DataProcess,
    onResultsAvailable: (List<Result>) -> Unit
) {
    val context = LocalContext.current

    val launcher =
        rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                val bitmap = getBitmapFromUri(context, it)
                val inputBuffer = dataProcess.bitmapToFloatBuffer(bitmap)
                val outputs = dataProcess.runModel(inputBuffer)
                val results = dataProcess.outputsToNPMSPredictions(outputs)

                onResultsAvailable(results)
            }
        }

    Column(modifier = Modifier.fillMaxSize()) {
        Button(onClick = { launcher.launch("image/*") }) {
            Text("Select Image from Gallery")
        }
    }
}

fun getBitmapFromUri(context: Context, uri: Uri): Bitmap {
    val source = ImageDecoder.createSource(context.contentResolver, uri)
    val bitmap = ImageDecoder.decodeBitmap(source)

    return if (bitmap.config == Bitmap.Config.HARDWARE) {
        bitmap.copy(Bitmap.Config.ARGB_8888, true)
    } else {
        bitmap
    }
}