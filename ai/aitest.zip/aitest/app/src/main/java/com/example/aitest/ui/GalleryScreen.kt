package com.example.aitest.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import com.example.aitest.DataProcess
import com.example.aitest.Result

@Composable
fun GalleryScreen(
    dataProcess: DataProcess,
    onResultsAvailable: (List<Result>) -> Unit
) {
    val context = LocalContext.current

    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    val launcher =
        rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
            uri?.let {
                selectedImageUri = it
                val bitmap = getBitmapFromUri(context, it)
                val inputBuffer = dataProcess.bitmapToFloatBuffer(bitmap)
                val outputs = dataProcess.runModel(inputBuffer)
                val results = dataProcess.outputsToNPMSPredictions(outputs)

                onResultsAvailable(results)
            }
        }

    Column(modifier = Modifier.fillMaxSize()) {
        Button(onClick = { launcher.launch("image/*") }) {
            Text("Select Image from Gallery")
        }

        selectedImageUri?.let { uri ->
            AsyncImage(model = uri, contentDescription = "", modifier = Modifier.fillMaxSize())
        }
    }
}

fun getBitmapFromUri(context: Context, uri: Uri): Bitmap {
    val source = ImageDecoder.createSource(context.contentResolver, uri)
    var bitmap = ImageDecoder.decodeBitmap(source)

    if (bitmap.config != Bitmap.Config.ARGB_8888) {
        bitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
    }

    if (bitmap.width != DataProcess.INPUT_SIZE || bitmap.height != DataProcess.INPUT_SIZE) {
        bitmap =
            Bitmap.createScaledBitmap(bitmap, DataProcess.INPUT_SIZE, DataProcess.INPUT_SIZE, true)
    }

    return if (bitmap.config == Bitmap.Config.HARDWARE) {
        bitmap.copy(Bitmap.Config.ARGB_8888, true)
    } else {
        bitmap
    }
}