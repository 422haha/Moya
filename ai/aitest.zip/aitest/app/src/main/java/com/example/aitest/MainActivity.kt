package com.example.aitest

import android.Manifest
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import com.example.aitest.ui.MainScreen
import com.example.aitest.ui.theme.AitestTheme

class MainActivity : ComponentActivity() {

    private lateinit var dataProcess: DataProcess

    private val requestCameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            startCameraPreview()
        } else {
            Toast.makeText(this, "카메라 권한이 필요합니다.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        dataProcess = DataProcess(context = this)
        dataProcess.loadModel()
        dataProcess.loadLabel()

        if (CheckPermissions.checkCameraPermission(this)) {
            startCameraPreview()
        } else {
            requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCameraPreview() {
        setContent {
            AitestTheme {
                MainScreen(dataProcess = dataProcess)
            }
        }
    }
}
