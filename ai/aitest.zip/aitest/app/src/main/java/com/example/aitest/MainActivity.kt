package com.example.aitest

import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.Manifest
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.example.aitest.ui.MainScreen
import com.example.aitest.ui.theme.AitestTheme

class MainActivity : ComponentActivity() {

    private lateinit var dataProcess: DataProcess

    private val requestCameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            // 권한이 허용되었을 때 Compose로 전환
            setContent {
                CameraPreviewScreen()
            }
        } else {
            Toast.makeText(this, "카메라 권한이 필요합니다.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        dataProcess = DataProcess(context = this)

        if (CheckPermissions.checkCameraPermission(this)) {
            // 권한이 있을 때 바로 Compose로 전환
            setContent {
                CameraPreviewScreen()
            }
        } else {
            // 권한 요청
            requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }
}

@Composable
fun CameraPreviewScreen() {
    // Compose에서 필요한 객체 초기화
    val context = LocalContext.current
    val dataProcess = remember { DataProcess(context = context) }
    val ortEnvironment = remember { OrtEnvironment.getEnvironment() }
    val session = remember {
        ortEnvironment.createSession(
            context.filesDir.absolutePath.toString() + "/" + DataProcess.FILE_NAME,
            OrtSession.SessionOptions()
        )
    }

    // 데이터 및 세션 초기화 (LaunchedEffect를 사용하여 한 번만 실행)
    LaunchedEffect(Unit) {
        dataProcess.loadModel()
        dataProcess.loadLabel()
    }

    // Theme 내에서 MainScreen 호출
    AitestTheme {
        MainScreen(
            dataProcess = dataProcess,
            ortEnvironment = ortEnvironment,
            session = session
        )
    }
}
