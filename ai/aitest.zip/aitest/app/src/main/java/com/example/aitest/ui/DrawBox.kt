package com.example.aitest.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.aitest.Result

@Composable
fun DrawBox(
    detectionResults: List<Result>
) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        detectionResults.forEach { result ->
            val rectF = result.rectF

            drawRoundRect(
                color = Color.Red,
                topLeft = Offset(rectF.left, rectF.top),
                size = Size(rectF.width(), rectF.height()),
                style = Stroke(width = 3f),
            )
        }
    }
}