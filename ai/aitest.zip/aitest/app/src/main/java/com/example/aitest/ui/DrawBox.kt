package com.example.aitest.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.aitest.Result

@Composable
fun DrawBox(detectionResults: List<Result>) {
    // 상태가 변하지 않을 때 불필요한 재구성을 막음
    val results = remember(detectionResults) { detectionResults }

    Canvas(modifier = Modifier.fillMaxSize()) {
        for (result in results) {
            drawRect(
                color = Color.Red,
                topLeft = Offset(result.rectF.left, result.rectF.top),
                size = Size(result.rectF.width(), result.rectF.height()),
                style = Stroke(width = 5f) // 테두리만 그리기
            )
        }
    }
}
