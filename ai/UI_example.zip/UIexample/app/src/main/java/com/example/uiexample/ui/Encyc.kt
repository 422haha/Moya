package com.example.uiexample.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uiexample.R

@Composable
fun EncycScreen() {
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar("도감")

        FilterChips()

        EncycGrid(items = List(8) { "능소화" }, modifier = Modifier.weight(1f))

        CollectionProgress(progress = 60.0f)
    }
}

@Composable
fun TopBar(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF8EB9A6))
            .padding(16.dp)
    ) {
        IconButton(onClick = { /* TODO: 뒤로 가기 */ }) {
            Icon(
                imageVector = Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = Color.White
            )
        }

        Text(text = text, fontSize = 18.sp, color = Color.White, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.width(48.dp))
    }
}

@Composable
fun FilterChipComponent(text: String, selected: Boolean) {
    FilterChip(
        selected = selected,
        onClick = { /* TODO: 필터 동작 추가 */ },
        label = {
            Text(
                text = text,
                color = if (selected) Color(0xFFFFFFFF) else Color(0xFF8EB9A6),
                fontWeight = FontWeight.Bold
            )
        },
        enabled = true,
        shape = RoundedCornerShape(16.dp),
        colors = FilterChipDefaults.filterChipColors(
            containerColor = if (selected) Color(0xFF8EB9A6) else Color(0xFFEFF2F7),
            selectedContainerColor = Color(0xFF8EB9A6),
            labelColor = if (selected) Color.White else Color(0xFF8EB9A6)
        ),
        border = if (!selected) {
            BorderStroke(1.dp, Color(0xFF8EB9A6))
        } else {
            null
        }
    )
}

@Composable
fun FilterChips() {
    Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        FilterChipComponent(text = "전체", selected = true)
        FilterChipComponent(text = "수집완료", selected = false)
        FilterChipComponent(text = "미발견", selected = false)
    }
}


@Composable
fun EncycGrid(items: List<String>, modifier: Modifier = Modifier) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(8.dp),
        modifier = modifier.fillMaxHeight()
    ) {
        items(items.size) { index ->
            val item = items[index]
            PlantCard(plantName = item, isDiscovered = item != "미발견 - 능소화")
        }
    }
}

@Composable
fun PlantCard(plantName: String, isDiscovered: Boolean) {
    Card(
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(4.dp),
        modifier = Modifier
            .padding(8.dp)
            .fillMaxWidth()
            .height(160.dp)
    ) {
        Column(
            modifier = Modifier
                .background(Color.White)
                .fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_launcher_foreground),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
            )

            Text(
                text = plantName,
                fontSize = 14.sp,
                color = if (isDiscovered) Color(0xFF4CAF50) else Color.Gray,
                modifier = Modifier
                    .padding(8.dp),
            )
        }
    }
}

@Composable
fun CollectionProgress(progress: Float) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Text(text = "수집률", fontSize = 16.sp, color = Color.Gray)

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = Color(0xFFFFB74D),
            )

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = "$progress%",
                fontWeight = FontWeight.Bold,
                color = Color.Gray
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun EncycScreenPreview() {
    EncycScreen()
}

@Preview(showBackground = true)
@Composable
fun CollectionProgressPreview() {
    CollectionProgress(60.0f)
}