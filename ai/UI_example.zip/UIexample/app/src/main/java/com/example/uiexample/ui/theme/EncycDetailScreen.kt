package com.example.uiexample.ui.theme

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.uiexample.R
import com.example.uiexample.ui.TopBar

@Composable
fun EncycDetailScreen() {
    Column(modifier = Modifier.fillMaxSize()) {
        TopBar(text = "능소화")

        ImageWithButton()

        IntroductionSection()
    }
}

@Composable
fun ImageWithButton() {
    Surface(
        modifier = Modifier
            .fillMaxWidth(),
        shape = RoundedCornerShape(bottomEnd = 16.dp, bottomStart = 16.dp),
        shadowElevation = 4.dp,
        color = Color(0xFF8EB9A6)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_launcher_background),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(8.dp))
            )
            Surface(
                modifier = Modifier
                    .wrapContentWidth()
                    .height(44.dp)
                    .padding(8.dp),
                shape = RoundedCornerShape(50),
                color = Color(0xFF8EB9A6),
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .padding(horizontal = 16.dp)
                ) {
                    Icon(
                        painter = painterResource(id = R.drawable.ic_launcher_foreground),
                        contentDescription = "도감 사진 보기",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = "도감 사진 보기",
                        color = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun IntroductionSection() {
    var expanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        // '소개' 제목
        Text(
            text = "소개",
            fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
            color = Color(0xFF8EB9A6),
            modifier = Modifier.padding(bottom = 8.dp)
        )

        // 텍스트 내용
        Box(
            modifier = Modifier.fillMaxWidth()
        ) {
            if (expanded) {
                Text(
                    text = "중국 원산의 갈잎 덩굴성 목본식물이다. 단절이름으로... (전체 텍스트가 여기에 들어갑니다)",
                    color = Color.Gray
                )
            } else {
                Text(
                    text = "중국 원산의 갈잎 덩굴성 목본식물이다. 단절이름으로...",
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    color = Color.Gray
                )
            }

            ClickableText(
                text = AnnotatedString(if (expanded) "접기" else "더보기"),
                onClick = { expanded = !expanded },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(top = 4.dp),
                style = TextStyle(color = Color.Blue)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(
            modifier = Modifier.fillMaxWidth()
        ) {
            IconButton(
                onClick = { /* TODO */ },
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFFEFF2F7))
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_launcher_foreground), // 임시 아이콘
                    contentDescription = "오디오 재생",
                    tint = Color(0xFF8EB9A6)
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ImageWithButtonPreview() {
    ImageWithButton()
}

@Preview(showBackground = true)
@Composable
fun EncycDetailScreenPreview() {
    EncycDetailScreen()
}