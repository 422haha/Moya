package com.example.uiexample.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.uiexample.R

@Composable
fun HomeScreen() {
    Scaffold(
        content = { paddingValues ->
            Column(
                modifier = Modifier
                    .padding(paddingValues)
                    .padding(8.dp)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                UserInfo()
                HomeBox(text = "나의 모험")
                HomeBox(text = "모험을 떠나요")
            }
        }
    )
}


@Composable
fun UserInfo() {
    Surface(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(8.dp)) {
            Image(
                painterResource(id = R.drawable.ic_launcher_foreground),
                contentDescription = "유저 이름",
                modifier = Modifier
                    .clip(CircleShape)
                    .size(50.dp)
                    .background(Color.Gray)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(text = "유저이름", modifier = Modifier.align(Alignment.CenterVertically))
        }
    }
}

@Composable
fun HomeBox(text: String) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .padding(bottom = 12.dp),
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF9C6644)
    ) {
        //TODO 추후에 기록에 따라 텍스트와 버튼이 보일지 분기 처리
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = text,
                    modifier = Modifier
                        .padding(vertical = 20.dp)
                        .padding(start = 12.dp)
                        .align(alignment = Alignment.CenterVertically),
                    color = Color.White
                )
                IconButton(
                    onClick = { /* TODO */ },
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                        contentDescription = "Go",
                        tint = Color.White
                    )
                }
            }

            BoxWithImage()
        }
    }
}

//TODO 나중에 modifier로 border받아서 적용해주기
@Composable
fun BoxWithImage() {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .clip(RoundedCornerShape(12.dp)),
        color = Color(0xFFA0D995)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .padding(8.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_launcher_background),
                    contentDescription = "캘린더",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        //TODO 나중에 높이 값 수정 필요할듯??
                        .height(200.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painterResource(id = R.drawable.ic_launcher_foreground),
                        contentDescription = "핀마커",
                        modifier = Modifier.size(32.dp)
                    )
                    Text(
                        text = "500m",
                        color = Color.White,
                        modifier = Modifier
                            .padding(vertical = 16.dp)
                            .padding(start = 8.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = "동락공원",
                modifier = Modifier
                    .align(Alignment.CenterHorizontally),
                color = Color.Black
            )
            Spacer(modifier = Modifier.height(18.dp))
        }
    }
}

@Preview(showBackground = true)
@Composable
fun HomeScreenPreview() {
    HomeScreen()
}

@Preview(showBackground = true)
@Composable
fun BoxWithImagePreview() {
    BoxWithImage()
}

@Preview(showBackground = true)
@Composable
fun HomeBoxPreview() {
    HomeBox(text = "헬로")
}